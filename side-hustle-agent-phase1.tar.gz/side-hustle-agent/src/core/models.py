"""Core domain models. Provider and LLM independent."""
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Optional


class OpportunityType(str, Enum):
    TRADING = "trading"
    ARBITRAGE = "arbitrage"
    ONLINE_BUSINESS = "online_business"
    AFFILIATE = "affiliate"
    DIGITAL_PRODUCT = "digital_product"
    COMPUTE = "compute"
    OTHER = "other"


class Decision(str, Enum):
    REJECT = "reject"
    PAPER_TEST = "paper_test"
    APPROVAL_REQUIRED = "approval_required"
    EXECUTE = "execute"
    NO_ACTION = "no_action"


@dataclass(frozen=True)
class Opportunity:
    id: str
    type: OpportunityType
    title: str
    required_capital: Decimal
    expected_revenue: Decimal
    expected_cost: Decimal
    estimated_probability: Decimal
    liquidity_score: Decimal = Decimal("1")
    confidence: Decimal = Decimal("0")
    source: Optional[str] = None

    @property
    def expected_net(self) -> Decimal:
        return self.expected_revenue - self.expected_cost

    @property
    def expected_value(self) -> Decimal:
        return self.expected_net * self.estimated_probability


@dataclass(frozen=True)
class CapitalLimits:
    total_capital: Decimal
    reserve_ratio: Decimal
    max_single_allocation: Decimal
    max_daily_loss: Decimal
    max_drawdown: Decimal
    max_leverage: Decimal = Decimal("1")

    @property
    def deployable_capital(self) -> Decimal:
        return self.total_capital * (Decimal("1") - self.reserve_ratio)


@dataclass(frozen=True)
class PortfolioState:
    allocated_today: Decimal = Decimal("0")
    realized_daily_pnl: Decimal = Decimal("0")
    peak_equity: Decimal = Decimal("0")
    current_equity: Decimal = Decimal("0")

    @property
    def drawdown(self) -> Decimal:
        if self.peak_equity <= 0:
            return Decimal("0")
        return max(Decimal("0"), self.peak_equity - self.current_equity)


@dataclass
class RiskDecision:
    decision: Decision
    reason: str
    opportunity_id: str
    checks: dict = field(default_factory=dict)
