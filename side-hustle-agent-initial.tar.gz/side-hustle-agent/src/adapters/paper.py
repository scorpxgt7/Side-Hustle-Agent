from dataclasses import dataclass
from decimal import Decimal


@dataclass
class PaperLedger:
    balance: Decimal = Decimal("0")

    def credit(self, amount: Decimal) -> None:
        if amount < 0:
            raise ValueError("credit amount must be non-negative")
        self.balance += amount

    def debit(self, amount: Decimal) -> None:
        if amount < 0:
            raise ValueError("debit amount must be non-negative")
        if amount > self.balance:
            raise ValueError("insufficient paper balance")
        self.balance -= amount
