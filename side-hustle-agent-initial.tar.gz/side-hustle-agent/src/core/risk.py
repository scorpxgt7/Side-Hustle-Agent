"""Deterministic risk governor. No LLM/model output may override these checks."""
from decimal import Decimal
from .models import CapitalLimits, Decision, Opportunity, RiskDecision


class RiskGovernor:
    def evaluate(self, opportunity: Opportunity, limits: CapitalLimits, allocated_today: Decimal = Decimal("0")) -> RiskDecision:
        checks = {}

        checks["capital_positive"] = opportunity.required_capital >= 0
        checks["within_single_allocation"] = opportunity.required_capital <= limits.max_single_allocation
        checks["within_deployable_capital"] = allocated_today + opportunity.required_capital <= limits.deployable_capital
        checks["positive_expected_value"] = opportunity.expected_value > 0
        checks["probability_valid"] = Decimal("0") <= opportunity.estimated_probability <= Decimal("1")
        checks["confidence_valid"] = Decimal("0") <= opportunity.confidence <= Decimal("1")

        if not all(checks.values()):
            failed = [name for name, ok in checks.items() if not ok]
            return RiskDecision(Decision.REJECT, f"Failed hard checks: {', '.join(failed)}", opportunity.id, checks)

        return RiskDecision(Decision.PAPER_TEST, "Passed deterministic discovery-stage checks; paper testing only.", opportunity.id, checks)
