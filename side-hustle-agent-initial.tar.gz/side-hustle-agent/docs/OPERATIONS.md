# OPERATIONS.md

## Mandatory pre-change procedure

Before modifying anything:

```text
READ PROJECT_CONTEXT.md
READ CHANGELOG.md
READ OPERATIONS.md
READ QA.md
CHECK CURRENT GIT/WORKTREE STATE
CHECK ACTIVE CAPITAL/EXECUTION MODE
THEN MODIFY
```

## Execution modes

### DISCOVERY
Find and normalize opportunities. No capital movement.

### PAPER
Simulate transactions with synthetic capital. No external monetary execution.

### APPROVAL
Prepare an executable action for human review. Do not execute automatically.

### LIVE
Reserved for a future release. Requires explicit enablement, isolated credentials, deterministic limits, monitoring, kill switch, reconciliation, and completed QA/security gates.

## Capital controls

Required controls for any future live profile:

- Maximum total deployable capital
- Maximum per-opportunity allocation
- Maximum daily loss
- Maximum aggregate drawdown
- Maximum leverage
- Maximum transaction value
- Maximum daily spend
- No withdrawal permission
- No credential creation without approval
- Automatic kill switch
- Reconciliation against authoritative account balances

## Incident response

Immediately disable execution if any of the following occurs:

- unexpected balance movement
- authentication anomaly
- repeated failed orders
- risk-limit calculation failure
- stale market data used for execution
- unexplained P&L discrepancy
- suspicious merchant/provider behavior
- corrupted or missing audit logs

Then preserve logs, switch to read-only/paper mode, and investigate before re-enabling.
