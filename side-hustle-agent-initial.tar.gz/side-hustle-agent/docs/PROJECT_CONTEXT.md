# PROJECT_CONTEXT.md

## Purpose

Build an autonomous side-hustle opportunity engine that searches broadly for legitimate online income opportunities, evaluates expected net economics, runs controlled experiments, records outcomes, and eventually allocates a bounded capital pool under deterministic risk controls.

## User objective

The system should look every day for ways to generate income online, potentially including algorithmic trading, arbitrage, crypto-related strategies, compute/mining economics, affiliate/business opportunities, digital products, services, data products, and other lawful opportunities.

The objective is **risk-adjusted long-term net profit**, not maximum daily activity or maximum leverage.

## Current phase

Phase 0 — architecture/scaffold/paper mode.

## Capital policy

- No debit-card credentials in code or prompts.
- No unrestricted account access.
- No withdrawals/transfers by the agent.
- No live trading in the initial build.
- All strategies begin in discovery or paper mode.
- Future capital must be isolated and explicitly bounded.
- Reserve capital must remain unavailable to individual workers.

## Core architecture

```text
Executive Orchestrator
        |
        +-- Opportunity Discovery
        |      +-- Markets
        |      +-- Arbitrage
        |      +-- Online Business
        |      +-- Compute/Mining Economics
        |      +-- Affiliate/Digital Products
        |
        +-- Economic Evaluation
        |
        +-- Risk Governor (deterministic)
        |
        +-- Paper Execution
        |
        +-- Ledger / P&L
        |
        +-- Audit Log
        |
        +-- Human Approval Boundary
```

## Required change-control protocol

Every change must:

1. Read this file, `CHANGELOG.md`, `OPERATIONS.md`, and `QA.md`.
2. State the intended change and affected components.
3. Check for conflicts with capital/risk rules.
4. Implement the smallest safe change.
5. Run relevant tests/verification.
6. Update `CHANGELOG.md`.
7. Update this file if architecture, behavior, interfaces, limits, dependencies, or decisions changed.
8. Update `OPERATIONS.md` if operating procedures changed.
9. Update `QA.md` if test coverage or acceptance criteria changed.
10. Record unresolved risks/blockers.

## Current decisions

- The LLM is an analyst/orchestrator, not the final authority for monetary limits.
- Risk limits are deterministic and must not be overridden by model output.
- The system must be able to return `NO_ACTION`.
- Opportunity evaluation must subtract fees, slippage, infrastructure costs, taxes where applicable, and expected failure/loss costs when estimable.
- Every executed/simulated action must have an audit record.
- Live integrations will use adapter interfaces and least-privilege credentials.

## Known blockers

- No writable GitHub repository is currently connected for this project.
- No brokerage/exchange/payment integrations have been authorized.
- No starting capital amount or jurisdiction-specific tax configuration has been supplied.
- No live execution should be enabled until security and QA gates exist.

## Next implementation step

Implement the deterministic domain model for opportunities, capital limits, risk decisions, paper orders, ledger entries, and audit events, then add worker interfaces and a daily simulation loop.
