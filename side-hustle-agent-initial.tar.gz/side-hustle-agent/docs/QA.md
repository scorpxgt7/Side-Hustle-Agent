# QA.md

## Release gates

A change cannot progress toward live execution unless all applicable gates pass.

### Domain correctness
- Monetary values use decimal/fixed-point semantics rather than binary floating point.
- Fees and slippage are included in economic calculations.
- Negative expected value is rejected.
- `NO_ACTION` is a valid outcome.

### Risk
- Risk limits are deterministic.
- Model output cannot override hard limits.
- Position sizing is bounded.
- Drawdown and daily-loss checks are tested.
- Kill switch behavior is tested.

### Security
- Secrets are never committed.
- Payment-card data is never stored.
- API credentials use least privilege.
- Withdrawal capability is disabled.
- Logs do not contain credentials or sensitive payment data.

### Reliability
- Failed external calls fail closed for execution.
- Stale data is detected.
- Duplicate execution is prevented with idempotency keys.
- Ledger reconciliation detects discrepancies.

### Auditability
- Every decision has an opportunity ID and decision ID.
- Every paper/live action has an audit event.
- Changes to limits are recorded.
- Context files are updated after relevant changes.
